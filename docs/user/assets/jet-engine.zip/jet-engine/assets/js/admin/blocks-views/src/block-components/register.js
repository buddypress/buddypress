const {
	CustomControl
} = window.JetEngineBlocksComponents;

const {
	registerBlockType
} = wp.blocks;

const {
	InspectorControls,
	MediaUpload
} = wp.blockEditor;

const {
	PanelBody,
	Disabled
} = wp.components;

const {
	serverSideRender: ServerSideRender
} = wp;

if ( window.JetEngineListingData.blockComponents ) {
	for ( var i = 0; i < window.JetEngineListingData.blockComponents.length; i++)  {
		
		const blockComponent = window.JetEngineListingData.blockComponents[ i ];

		registerBlockType( blockComponent.name, {
			title: blockComponent.title,
			attributes: blockComponent.attributes,
			category: 'jet-engine',
			usesContext: [ 'postId', 'postType', 'queryId' ],
			edit( props ) {

				const attributes = props.attributes;

				var object = window.JetEngineListingData.object_id;
				var listing = window.JetEngineListingData.settings;

				if ( props.context.queryId ) {
					object  = props.context.postId;
					listing = {
						listing_source: 'posts',
						listing_post_type: props.context.postType,
					};
				}

				return [
					props.isSelected && (
						<InspectorControls
							key={ 'inspector' }
						>
							<PanelBody title={ 'General' }>
								{ blockComponent.attributes 
								&& Object.keys( blockComponent.attributes ).length
								&& Object.keys( blockComponent.attributes ).map( ( attr ) => {
									
									const control = blockComponent.attributes[ attr ].controlType;
									
									return <CustomControl
										control={ control }
										value={ attributes[ attr ] }
										getValue={ ( name ) => {
											return attributes[ name ];
										} }
										onChange={ newValue => {
											props.setAttributes( { [ attr ]: newValue } );
										} }
									/>;
								} ) }
							</PanelBody>
						</InspectorControls>
					),
					<Disabled key={ 'block_render' }>
						<ServerSideRender
							block={ blockComponent.name }
							attributes={ attributes }
							urlQueryArgs={ {
								object: object,
								listing: listing,
								is_component_preview: 1,
							} }
						/>
					</Disabled>
				];
			},
			save: props => {
				return null;
			}
		} );

	}
}
